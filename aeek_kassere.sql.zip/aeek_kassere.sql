-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 21 mai 2022 à 21:15
-- Version du serveur : 10.4.19-MariaDB
-- Version de PHP : 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `aeek_kassere`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `date_admin` datetime DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `nom` varchar(225) NOT NULL,
  `prenom` varchar(225) NOT NULL,
  `email_valid` int(1) NOT NULL DEFAULT 0,
  `mot_de_passe` varchar(225) DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `iso_phone` varchar(225) DEFAULT NULL,
  `dial_phone` varchar(225) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL,
  `role` int(1) DEFAULT 0,
  `bloquer` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id_admin`, `date_admin`, `email`, `nom`, `prenom`, `email_valid`, `mot_de_passe`, `phone`, `iso_phone`, `dial_phone`, `photo`, `role`, `bloquer`) VALUES
(1, '2022-04-08 14:06:40', 'zie.nanien@gmail.com', 'Ouattara', 'Regis', 1, '$2y$12$pOGTVYKlboX25jpPsGfnbO5swWhVQW05ejZ9U0sUjw9NhmYVjYzH.', '05 46 85 9936', 'ci', '225', '62596481eb35e.png', 1, 0),
(2, '2022-04-15 19:29:52', 'membre@gmail.com', 'Zie', 'Mamba', 0, '$2y$12$pOGTVYKlboX25jpPsGfnbO5swWhVQW05ejZ9U0sUjw9NhmYVjYzH.', '05484444445', 'CI', '225', NULL, 0, 1),
(3, '2022-04-16 12:49:00', 'zie.nanien1@gmail.com', 'Gnelezie Arouna', 'Ouattara', 0, NULL, '000000000', 'ci', '225', NULL, 0, 0),
(4, '2022-04-16 12:52:00', 'wordpress@cinnove.com', 'mmpo', 'Ouattara', 0, NULL, '000000000', 'ci', '225', NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `id_article` int(11) NOT NULL,
  `date_article` datetime NOT NULL,
  `titre` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL,
  `categorie_id` int(11) DEFAULT NULL,
  `tags_id` varchar(50) DEFAULT NULL,
  `categorie` varchar(225) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `couverture` varchar(225) DEFAULT NULL,
  `statut` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`id_article`, `date_article`, `titre`, `slug`, `categorie_id`, `tags_id`, `categorie`, `user_id`, `description`, `couverture`, `statut`) VALUES
(1, '2022-05-21 18:52:00', 'Les coupes de la vie', 'les-coupes-de-la-vie', 6, NULL, NULL, 1, '<p>sqs ffff</p>', '628934e669804.png', 0),
(2, '2022-05-21 18:52:00', 'conjugaison en anglais', 'conjugaison-en-anglais', 5, NULL, NULL, 1, '<p>gggg</p>', '62893506c5311.png', 0),
(3, '2022-05-21 18:53:00', '100 jours pour ne plus faire de fautes', '100-jours-pour-ne-plus-faire-de-fautes', 2, NULL, NULL, 1, '<p>eeeeee</p>', '62893518267ef.jpg', 0),
(4, '2022-05-21 18:53:00', 'Cours 1', 'cours-1', 1, NULL, NULL, 1, '<p>ZFDSSD</p>', '62893535978e0.jpg', 0);

-- --------------------------------------------------------

--
-- Structure de la table `article_tags`
--

CREATE TABLE `article_tags` (
  `id_article_tags` int(11) NOT NULL,
  `date_article_tags` datetime NOT NULL,
  `article_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `article_tags`
--

INSERT INTO `article_tags` (`id_article_tags`, `date_article_tags`, `article_id`, `tag_id`) VALUES
(1, '2022-05-21 18:52:00', 1, 2),
(2, '2022-05-21 18:52:00', 1, 1),
(3, '2022-05-21 18:52:00', 2, 1),
(4, '2022-05-21 18:53:00', 3, 2),
(5, '2022-05-21 18:53:00', 4, 4);

-- --------------------------------------------------------

--
-- Structure de la table `banniere`
--

CREATE TABLE `banniere` (
  `id_banniere` int(11) NOT NULL,
  `date_banniere` datetime NOT NULL,
  `titre` varchar(100) DEFAULT NULL,
  `sous_titre` varchar(100) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL,
  `statut` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `banniere`
--

INSERT INTO `banniere` (`id_banniere`, `date_banniere`, `titre`, `sous_titre`, `photo`, `statut`) VALUES
(11, '2022-05-19 15:27:00', 'Bienvenue &agrave; Kass&eacute;r&eacute;', 'La plateforme 100% Kass&eacute;r&eacute;laise avec toutes les informations', '628661e707103.jpg', 0),
(12, '2022-05-19 15:28:00', 'Bienvenue Lyc&eacute;e Moderne de Kass&eacute;r&eacute;', 'La plateforme 100% LMK avec toutes les informations', '6286620ecf6ea.jpg', 0);

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id_categorie` int(11) NOT NULL,
  `date_categorie` datetime DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id_categorie`, `date_categorie`, `nom`, `slug`) VALUES
(1, '2022-05-02 21:40:00', 'Soci&eacute;t&eacute;', 'societe'),
(2, '2022-05-02 21:40:00', 'Politique', 'politique'),
(3, '2022-05-02 21:40:00', 'Informatique', 'informatique'),
(4, '2022-05-10 08:16:00', 'Sport', 'sport'),
(5, '2022-05-10 08:16:00', 'Sant&eacute;', 'sante'),
(6, '2022-05-10 08:16:00', 'Economie', 'economie');

-- --------------------------------------------------------

--
-- Structure de la table `comment`
--

CREATE TABLE `comment` (
  `id_comment` int(11) NOT NULL,
  `date_comment` datetime NOT NULL,
  `article_id` int(11) DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `statut` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `events`
--

CREATE TABLE `events` (
  `id_events` int(11) NOT NULL,
  `date_events` datetime NOT NULL,
  `nom` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `reponse`
--

CREATE TABLE `reponse` (
  `id_reponse` int(11) NOT NULL,
  `date_reponse` datetime DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  `comment_id` int(11) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `statut` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `stats_visite`
--

CREATE TABLE `stats_visite` (
  `ip` varchar(30) NOT NULL,
  `date_visite` date NOT NULL,
  `navigateur` varchar(55) DEFAULT NULL,
  `devices` varchar(55) DEFAULT NULL,
  `pages_vues` smallint(5) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `stats_visite`
--

INSERT INTO `stats_visite` (`ip`, `date_visite`, `navigateur`, `devices`, `pages_vues`) VALUES
('::1', '2022-05-21', 'Chrome', 'pc', 17),
('127.0.0.1', '2022-05-21', 'Firefox', 'pc', 2);

-- --------------------------------------------------------

--
-- Structure de la table `tag`
--

CREATE TABLE `tag` (
  `id_tag` int(11) NOT NULL,
  `date_tag` datetime NOT NULL,
  `nom` varchar(55) DEFAULT NULL,
  `slug` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tag`
--

INSERT INTO `tag` (`id_tag`, `date_tag`, `nom`, `slug`) VALUES
(1, '2022-05-21 18:51:00', 'UVCI', 'uvci'),
(2, '2022-05-21 18:51:00', 'EXOS', 'exos'),
(3, '2022-05-21 18:53:00', 'UVCT', 'uvct'),
(4, '2022-05-21 18:53:00', 'UVCT', 'uvct-1');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_2` (`email`);

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id_article`);

--
-- Index pour la table `article_tags`
--
ALTER TABLE `article_tags`
  ADD PRIMARY KEY (`id_article_tags`),
  ADD KEY `article_id` (`article_id`),
  ADD KEY `tag_id` (`tag_id`);

--
-- Index pour la table `banniere`
--
ALTER TABLE `banniere`
  ADD PRIMARY KEY (`id_banniere`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id_categorie`);

--
-- Index pour la table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id_comment`),
  ADD KEY `article_id` (`article_id`);

--
-- Index pour la table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id_events`);

--
-- Index pour la table `reponse`
--
ALTER TABLE `reponse`
  ADD PRIMARY KEY (`id_reponse`),
  ADD KEY `comment_id` (`comment_id`);

--
-- Index pour la table `stats_visite`
--
ALTER TABLE `stats_visite`
  ADD PRIMARY KEY (`ip`,`date_visite`),
  ADD KEY `date_visite` (`date_visite`);

--
-- Index pour la table `tag`
--
ALTER TABLE `tag`
  ADD PRIMARY KEY (`id_tag`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `article`
--
ALTER TABLE `article`
  MODIFY `id_article` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `article_tags`
--
ALTER TABLE `article_tags`
  MODIFY `id_article_tags` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `banniere`
--
ALTER TABLE `banniere`
  MODIFY `id_banniere` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id_categorie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `comment`
--
ALTER TABLE `comment`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `events`
--
ALTER TABLE `events`
  MODIFY `id_events` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `reponse`
--
ALTER TABLE `reponse`
  MODIFY `id_reponse` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `tag`
--
ALTER TABLE `tag`
  MODIFY `id_tag` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
