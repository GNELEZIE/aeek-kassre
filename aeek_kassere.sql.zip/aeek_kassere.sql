-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 17 mai 2022 à 16:55
-- Version du serveur : 10.4.19-MariaDB
-- Version de PHP : 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `aeek_kassere`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `date_admin` datetime DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `nom` varchar(225) NOT NULL,
  `prenom` varchar(225) NOT NULL,
  `email_valid` int(1) NOT NULL DEFAULT 0,
  `mot_de_passe` varchar(225) DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `iso_phone` varchar(225) DEFAULT NULL,
  `dial_phone` varchar(225) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL,
  `role` int(1) DEFAULT 0,
  `bloquer` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id_admin`, `date_admin`, `email`, `nom`, `prenom`, `email_valid`, `mot_de_passe`, `phone`, `iso_phone`, `dial_phone`, `photo`, `role`, `bloquer`) VALUES
(1, '2022-04-08 14:06:40', 'zie.nanien@gmail.com', 'Ouattara', 'Regis', 1, '$2y$12$pOGTVYKlboX25jpPsGfnbO5swWhVQW05ejZ9U0sUjw9NhmYVjYzH.', '05 46 85 9936', 'ci', '225', '62596481eb35e.png', 1, 0),
(2, '2022-04-15 19:29:52', 'membre@gmail.com', 'Zie', 'Mamba', 0, '$2y$12$pOGTVYKlboX25jpPsGfnbO5swWhVQW05ejZ9U0sUjw9NhmYVjYzH.', '05484444445', 'CI', '225', NULL, 0, 1),
(3, '2022-04-16 12:49:00', 'zie.nanien1@gmail.com', 'Gnelezie Arouna', 'Ouattara', 0, NULL, '000000000', 'ci', '225', NULL, 0, 0),
(4, '2022-04-16 12:52:00', 'wordpress@cinnove.com', 'mmpo', 'Ouattara', 0, NULL, '000000000', 'ci', '225', NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `id_article` int(11) NOT NULL,
  `date_article` datetime NOT NULL,
  `titre` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL,
  `categorie_id` int(11) DEFAULT NULL,
  `categorie` varchar(225) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `couverture` varchar(225) DEFAULT NULL,
  `statut` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`id_article`, `date_article`, `titre`, `slug`, `categorie_id`, `categorie`, `user_id`, `description`, `couverture`, `statut`) VALUES
(1, '2022-05-10 08:18:00', 'Aucun cas de COVID-19 d&eacute;tect&eacute; le 9 mai 2022', 'aucun-cas-de-covid-19-detecte-le-9-mai-2022', 5, NULL, 1, '<p>Abidjan- Le ministère de la Santé, de l’Hygiène publique et de la Couverture maladie universelle a enregistré lundi 9 mai 2022, zéro nouveau cas de COVID-19 sur 353 échantillons prélevés soit 0% de cas positifs, deux guéris et zéro décès.</p><p>\"A la date du 9 mai 2022, la Côte d’Ivoire compte donc 81 974 cas confirmés dont 81 162 personnes guéries, 799 décès et 4 cas actifs. Le nombre total d’échantillons est de 1 507 385. Le 8 mai, 24 798 doses de vaccin ont été administrées soit un total de 12 541 894 doses du 1er mars 2021 au 8 mai 2022\", rapporte un communiqué du ministère.</p><p>Le ministre Pierre Dimba invite toutes les personnes de plus de 12 ans à se faire vacciner dans les centres de vaccination. La vaccination contre la COVID-19 est gratuite et volontaire.</p>', '627a1fc19c21f.jpg', 0),
(2, '2022-05-10 08:32:00', 'Le pr&eacute;sident de la Cour de justice de la CEDEAO rel&egrave;ve les contraintes de l&rsquo;institution', 'le-president-de-la-cour-de-justice-de-la-cedeao-releve-les-contraintes-de-linstitution', 2, NULL, 1, '<p>Praia (Cap-Vert)- Le président de la Cour de justice de la CEDEAO, Edward Amoako Asante, a relevé lundi à Praia, au Cap-Vert, les contraintes liées au fonctionnement optimum de cet instrument juridique sous-régional, à l’ouverture de la conférence internationale de l’institution.t conférence portant sur le thème « Modèle d’intégration de la CEDEAO : les implications juridiques du régionalisme, de la souveraineté et du supranationalisme » a été ouverte par le président du Cap-Vert, José Maria Neves.our Edward Amoako Asante, plusieurs contraintes militent contre la réalisation des objectifs de la Communauté, notamment l’absence d’un ordre juridique communautaire fonctionnel qui mette en évidence les relations juridiques entre les États membres et les institutions de la CEDEAO et entre la Cour de justice de la CEDEAO et les tribunaux nationaux des États membres.</p><p>De même, a-t-il dit, bien que la Cour de justice de la CEDEAO soit un modèle parmi les cours régionales en Afrique, certains facteurs militent contre elle dans l’accomplissement de ses mandats, dont certains constituent des menaces existentielles pour la Cour. Il a cité la réduction du nombre de juges de la Cour de sept, comme prévu dans le Protocole initial relatif à la Cour, à cinq en 2018. « Cela nous préoccupe beaucoup et a un effet négatif sur le fonctionnement de notre institution », a-t-il indiqué.</p><p>Le président a expliqué que malgré tous les efforts déployés par l’actuel collège de juges, le nombre d’affaires pendantes devant la Cour continue de croître de manière astronomique. « Compte tenu de la charge de travail croissante de la Cour, il est évident qu’une Cour composée de seulement cinq membres ne peut pas faire face. Il est également difficile de constituer plus d’une chambre à la Cour, puisqu’une chambre requiert un minimum de trois juges », a-t-il exprimé.</p><p><br></p><p><br></p><p><br></p><p>Le juge Amoako Asante a suggéré que les États membres envisagent de rétablir la composition de la Cour à sept membres, comme le prévoit le Protocole initial relatif à la Cour, au moment opportun.</p><p><br></p><p><br></p><p><br></p><p>Selon lui, la réduction du mandat des juges de cinq ans renouvelables à quatre ans non renouvelables n’est pas non plus dans l’intérêt de la Cour ou de la Communauté, car il n’existe pas de Cour ou de tribunal international dont la durée du mandat des juges est aussi réduite. « Il n’est pas souhaitable d’aligner la durée du mandat des juges de la Cour sur celle du mandat des commissaires de la Commission, qui sont des personnalités nommées pour des raisons politique », a-t-il conseillé.</p><p><br></p><p><br></p><p><br></p><p>Le juge a expliqué que le mandat des fonctionnaires judiciaires est différent de celui des personnes nommées par le pouvoir politique. « Le renouvellement complet de la composition de la Cour, comme cela a été fait en 2014 et 2018, par opposition à l’échelonnement des mandats des juges tel qu’envisagé dans le protocole initial, n’est pas non plus dans l’intérêt de la Cour et de la Communauté, car cela entraîne une perte totale de la mémoire institutionnelle », a-t-il dit.</p><p><br></p><p><br></p><p><br></p><p>Le patron de la Cour a relevé que le faible taux d’exécution des arrêts de la Cour, qui s’élève actuellement à environ 30%, est également une source de grave préoccupation l’institution. Il a dit regretté que seuls six États membres aient désigné les autorités nationales compétentes pour l’exécution des arrêts de la Cour sur leur territoire respectif, notamment la République de Guinée, du Nigeria, du Mali, du Burkina Faso, du Togo et du Ghana.</p><p><br></p><p><br></p><p><br></p><p>« Nous continuerons à demander aux États membres restants de faire le nécessaire et j’espère que cette conférence internationale, ici au Cap-Vert, aboutira à la nomination de son autorité nationale compétente, comme notre conférence de 2019 au Ghana a réussi à le faire », a conclu le juge.</p>', '627a23343d716.jpg', 0),
(3, '2022-05-10 08:49:00', 'Non respect des sanctions CEDEAO contre le Mali : la compagnie ASKY somm&eacute;e de suspendre sa desserte de Bamako &agrave; partir d&rsquo;Abidjan', 'non-respect-des-sanctions-cedeao-contre-le-mali-la-compagnie-asky-sommee-de-suspendre-sa-desserte-de-bamako-a-partir-dabidjan', 6, NULL, 1, '<p>Cette sommation émane de la Direction générale de l’Autorité Nationale de l’Aviation Civile de la Côte d’Ivoire (ANAC RCI). Celle-ci a signifié cet ordre par le canal d’une lettre datant du 24 février 2022 et signée de son premier responsable M. Sinaly SILUE. Dans ce message dont copie nous est parvenue, le DG de l’ANAC Côte d’Ivoire a martelé que des instructions seraient données aux structures aéroportuaires concernées pour un strict respect de cette mesure. Voici ici l’intégralité de cette lettre adressée au Directeur Général de la compagnie aérienne ASKY basée à Lomé au Togo.</p><p>Monsieur le Directeur Général,</p><p>J’ai été saisi de ce que ASKY opère sur la liaison Abidjan/Bamako via Conakry au mépris de la décision prise à l’issue du 4ème sommet extraordinaire de la conférence des Chefs d’Etat et de Gouvernement de la CEDEAO sur la situation au Mali, tenu le 9 janvier 2022 à Accra au Ghana.</p><p>Je vous demande, par conséquent, de suspendre dès réception de la présente, l’exploitation des droits de trafic passagers sur la liaison Abidjan/Bamako et vice versa.&nbsp;</p><p>Des instructions seront données aux structures aéroportuaires concernées pour un strict respect de cette mesure.</p><p>Veuillez agréer, Monsieur le Directeur Général, l’assurance de ma considération distinguée.</p>', '627a272b0046e.jpg', 0);

-- --------------------------------------------------------

--
-- Structure de la table `banniere`
--

CREATE TABLE `banniere` (
  `id_banniere` int(11) NOT NULL,
  `date_banniere` datetime NOT NULL,
  `titre` varchar(100) DEFAULT NULL,
  `sous_titre` varchar(100) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL,
  `statut` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `banniere`
--

INSERT INTO `banniere` (`id_banniere`, `date_banniere`, `titre`, `sous_titre`, `photo`, `statut`) VALUES
(1, '2022-05-17 14:55:00', 'Les coupes de la vie', 'teset', '6283b7473aad4.jpg', 0);

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id_categorie` int(11) NOT NULL,
  `date_categorie` datetime DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id_categorie`, `date_categorie`, `nom`, `slug`) VALUES
(1, '2022-05-02 21:40:00', 'Soci&eacute;t&eacute;', 'societe'),
(2, '2022-05-02 21:40:00', 'Politique', 'politique'),
(3, '2022-05-02 21:40:00', 'Informatique', 'informatique'),
(4, '2022-05-10 08:16:00', 'Sport', 'sport'),
(5, '2022-05-10 08:16:00', 'Sant&eacute;', 'sante'),
(6, '2022-05-10 08:16:00', 'Economie', 'economie');

-- --------------------------------------------------------

--
-- Structure de la table `comment`
--

CREATE TABLE `comment` (
  `id_comment` int(11) NOT NULL,
  `date_comment` datetime NOT NULL,
  `article_id` int(11) DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `statut` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `comment`
--

INSERT INTO `comment` (`id_comment`, `date_comment`, `article_id`, `nom`, `email`, `message`, `statut`) VALUES
(1, '2022-05-13 09:37:00', 1, 'Ouattara', 'octavie@gmail.com', 'Le ministre Pierre Dimba invite toutes les personnes de plus de 12 ans &agrave; se faire vacciner dans les centres de vaccination.', 0),
(2, '2022-05-13 09:41:00', 1, 'Ouattara', 'octavie@gmail.com', 'Le ministre Pierre Dimba invite toutes les personnes de plus de 12 ans &agrave; se faire vacciner dans les centres de vaccination.', 0),
(3, '2022-05-13 09:41:00', 1, 'Gnelezie Arouna', 'wordpress@cinnove.com', 'ffff', 1),
(5, '2022-05-13 09:43:00', 3, 'Kone', 'Prnom@kk.mm', 'de suspendre d&egrave;s r&eacute;ception de la pr&eacute;sente, l&rsquo;exploitation des droits de trafic passagers sur la liaison Abidjan/Bamak', 1),
(6, '2022-05-13 10:01:00', 2, 'mmpo', 'wordpress@cinnove.com', 'pp!', 1),
(7, '2022-05-13 10:14:00', 2, 'Gnelezie Arouna', 'wordpress@cinnove.com', 'ss ddd', 1),
(8, '2022-05-14 10:59:00', 1, 'Ouattara', 'octavie@gmail.com', 'contre la COVID-19 est gratuite et volontaire.', 0),
(9, '2022-05-14 11:00:00', 1, 'Kone', 'octavie@gmail.com', 'La C&ocirc;te d&rsquo;Ivoire compte donc 81 974 cas confirm&eacute;s dont 81 162 personnes gu&eacute;ries, 799 d&eacute;c&egrave;s et 4 cas actifs. Le nombre total d&rsquo;&eacute;chantillons est de 1 507 385', 1),
(10, '2022-05-14 11:00:00', 1, 'Kone', 'octavie@Sgmail.com', 'Hygi&egrave;ne publique et de la Couverture maladie universelle a enregistr&eacute; lundi 9 mai', 1);

-- --------------------------------------------------------

--
-- Structure de la table `reponse`
--

CREATE TABLE `reponse` (
  `id_reponse` int(11) NOT NULL,
  `date_reponse` datetime DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  `comment_id` int(11) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `statut` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `reponse`
--

INSERT INTO `reponse` (`id_reponse`, `date_reponse`, `article_id`, `comment_id`, `email`, `nom`, `message`, `statut`) VALUES
(1, '2022-05-13 11:53:03', 3, 5, 'zie@.ci.co', 'Sangar', 'Le lorem ipsum est, en imprimerie, une suite de mots sans signification utilisée à t', 0),
(2, '2022-05-13 10:00:00', 3, 5, 'wordpress@cinnove.com', 'Repos 6', 'ddddd', 0),
(3, '2022-05-13 10:13:00', 2, 6, 'wordpress@cinnove.com', 'Repos 2', 'sssssss', 0),
(4, '2022-05-13 10:13:00', 2, 6, 'wordpress@cinnove.com', 'Repos 2', 'sssssss', 0),
(5, '2022-05-13 10:13:00', 2, 6, 'Prnom@kk.mm', 'hummmm', 'fffffgggg', 0),
(6, '2022-05-13 10:13:00', 2, 6, 'Prnom@kk.mm', 'hummmm', 'fffffgggg', 0),
(7, '2022-05-13 10:14:00', 2, 7, 'wordpress@cinnove.com', 'Repos 2', 'sssser tty', 0),
(8, '2022-05-13 10:15:00', 2, 7, 'octavie@gmail.com', 'Repos 6', 'zzzz', 0),
(9, '2022-05-13 10:15:00', 2, 7, 'octavie@gmail.com', 'Repos 6', 'aaa', 0),
(10, '2022-05-13 10:17:00', 3, 5, 'wordpress@cinnove.com', 'Repos', 'mmpp', 0),
(11, '2022-05-13 10:43:00', 2, 7, 'zie.nanien@gmail.com', 'Ouattara', 'dddss admin', 0),
(12, '2022-05-14 11:01:00', 1, 10, 'wordpress@cinnove.com', 'Repos 6', 'Hygi&egrave;ne publique et de la Couverture maladie universelle a enregistr&eacute; lundi 9 mai', 0);

-- --------------------------------------------------------

--
-- Structure de la table `stats_visite`
--

CREATE TABLE `stats_visite` (
  `ip` varchar(30) NOT NULL,
  `date_visite` date NOT NULL,
  `navigateur` varchar(55) DEFAULT NULL,
  `devices` varchar(55) DEFAULT NULL,
  `pages_vues` smallint(5) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `stats_visite`
--

INSERT INTO `stats_visite` (`ip`, `date_visite`, `navigateur`, `devices`, `pages_vues`) VALUES
('::1', '2022-05-14', 'Chrome', 'pc', 51),
('127.0.0.1', '2022-05-14', 'Firefox', 'mobile', 2),
('127.0.0.1', '2022-05-17', 'Chrome', 'pc', 1),
('::1', '2022-05-17', 'Chrome', 'pc', 2);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_2` (`email`);

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id_article`);

--
-- Index pour la table `banniere`
--
ALTER TABLE `banniere`
  ADD PRIMARY KEY (`id_banniere`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id_categorie`);

--
-- Index pour la table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id_comment`),
  ADD KEY `article_id` (`article_id`);

--
-- Index pour la table `reponse`
--
ALTER TABLE `reponse`
  ADD PRIMARY KEY (`id_reponse`),
  ADD KEY `comment_id` (`comment_id`);

--
-- Index pour la table `stats_visite`
--
ALTER TABLE `stats_visite`
  ADD PRIMARY KEY (`ip`,`date_visite`),
  ADD KEY `date_visite` (`date_visite`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `article`
--
ALTER TABLE `article`
  MODIFY `id_article` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `banniere`
--
ALTER TABLE `banniere`
  MODIFY `id_banniere` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id_categorie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `comment`
--
ALTER TABLE `comment`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `reponse`
--
ALTER TABLE `reponse`
  MODIFY `id_reponse` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
