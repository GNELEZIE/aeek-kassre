-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 23 mai 2022 à 00:41
-- Version du serveur : 10.4.19-MariaDB
-- Version de PHP : 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `aeek_kassere`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `date_admin` datetime DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `nom` varchar(225) NOT NULL,
  `prenom` varchar(225) NOT NULL,
  `email_valid` int(1) NOT NULL DEFAULT 0,
  `mot_de_passe` varchar(225) DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `iso_phone` varchar(225) DEFAULT NULL,
  `dial_phone` varchar(225) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL,
  `role` int(1) DEFAULT 0,
  `bloquer` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id_admin`, `date_admin`, `email`, `nom`, `prenom`, `email_valid`, `mot_de_passe`, `phone`, `iso_phone`, `dial_phone`, `photo`, `role`, `bloquer`) VALUES
(1, '2022-04-08 14:06:40', 'zie.nanien@gmail.com', 'Ouattara', 'Regis', 1, '$2y$12$pOGTVYKlboX25jpPsGfnbO5swWhVQW05ejZ9U0sUjw9NhmYVjYzH.', '05 46 85 9936', 'ci', '225', '62596481eb35e.png', 1, 0),
(2, '2022-04-15 19:29:52', 'membre@gmail.com', 'Zie', 'Mamba', 1, '$2y$12$pOGTVYKlboX25jpPsGfnbO5swWhVQW05ejZ9U0sUjw9NhmYVjYzH.', '05484444445', 'CI', '225', '62596481eb35e.png', 1, 0),
(3, '2022-04-16 12:49:00', 'zie.nanien1@gmail.com', 'Gnelezie Arouna', 'Ouattara', 0, NULL, '000000000', 'ci', '225', NULL, 0, 0),
(4, '2022-04-16 12:52:00', 'wordpress@cinnove.com', 'mmpo', 'Ouattara', 0, NULL, '000000000', 'ci', '225', NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `id_article` int(11) NOT NULL,
  `date_article` datetime NOT NULL,
  `titre` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL,
  `categorie_id` int(11) DEFAULT NULL,
  `tags_id` varchar(50) DEFAULT NULL,
  `categorie` varchar(225) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `couverture` varchar(225) DEFAULT NULL,
  `statut` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`id_article`, `date_article`, `titre`, `slug`, `categorie_id`, `tags_id`, `categorie`, `user_id`, `description`, `couverture`, `statut`) VALUES
(1, '2022-05-22 10:17:00', 'Festival des musiques urbaines d&rsquo;Anoumabo (FEMUA)', 'festival-des-musiques-urbaines-danoumabo-femua', 8, NULL, NULL, 2, '<p><span style=\"font-size: 14px;\">Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participantsLe Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants</span><br></p>', '628a0dc546093.jpg', 0),
(2, '2022-05-22 10:18:00', 'Le Premier ministre ivoirien Patrick Achi a communi&eacute; avec les participants &agrave; la 14e &eacute;dition du Festival des musiques urbaines d&rsquo;Anoumabo (FEMUA). Parrain de cette &eacute;dition', 'le-premier-ministre-ivoirien-patrick-achi-a-communie-avec-les-participants-a-la-14e-edition-du-festival-des-musiques-urbaines-danoumabo-femua-parrain-de-cette-edition', 6, NULL, NULL, 2, '<p><span style=\"font-size: 14px;\">Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participantsLe Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participantsLe Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participantsLe Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants Le Premier ministre ivoirien Patrick Achi a communié avec les participants à la 14e édition du Festival des musiques urbaines d’Anoumabo (FEMUA). Parrain de cette édition, le chef duLe Premier ministre ivoirien Patrick Achi a communié avec les participants</span><br></p>', '628a0de0c4f63.jpg', 0),
(3, '2022-05-22 10:29:00', 'Dans l&rsquo;univers des femmes qui font des enfants sans l&rsquo;accord de leur conjoint', 'dans-lunivers-des-femmes-qui-font-des-enfants-sans-laccord-de-leur-conjoint', 1, NULL, NULL, 2, '<p><span style=\"font-size: 14px;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à son arrivée. Le choix de la chambre et sa décoration sont autant de projets à avoir àFaire de la place pour bébé, c’est accepter sa présence et se préparer à son arrivée. Le choix de la chambre et sa décoration sont autant de projets à avoir àFaire de la place pour bébé, c’est accepter sa présence et se préparer à son arrivée. Le choix de la chambre et sa décoration sont autant de projets à avoir àFaire de la place pour bébé, c’est accepter sa présence et se préparer à son arrivée. Le choix de la chambre et sa décoration sont autant de projets à avoir àFaire de la place pour bébé, c’est accepter sa présence et se préparer à son arrivée. Le choix de la chambre et sa décoration sont autant de projets à avoir àFaire de la place pour bébé, c’est accepter sa présence et se préparer à son arrivée. Le choix de la chambre et sa décoration sont autant de projets à avoir àFaire de la place pour bébé, c’est accepter sa présence et se préparer à son arrivée. Le choix de la chambre et sa décoration sont autant de projets à avoir à</span><br></p>', '628a108154a2b.jpg', 0),
(4, '2022-05-22 10:32:00', 'Faire de la place pour b&eacute;b&eacute;, c&rsquo;est accepter sa pr&eacute;sence et se pr&eacute;parer &agrave;', 'faire-de-la-place-pour-bebe-cest-accepter-sa-presence-et-se-preparer-a', 1, NULL, NULL, 2, '<p><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa pré</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">Faire de la place pour bébé, c’est accepter sa présence et se préparer à</span><span style=\"color: rgb(105, 105, 105); font-family: Archivo, sans-serif;\">sence et se préparer à</span></p>', '628a114a3cc6b.jpg', 0),
(5, '2022-05-22 10:37:00', 'Ecole Maternelle et Primaire Le Petit Baobab', 'ecole-maternelle-et-primaire-le-petit-baobab', 1, NULL, NULL, 2, '<p><span style=\"font-size: 14px;\">Anciennement, école primaire publique dirigée par un instituteur, une institutrice laïque ; dans un sens plus général, enseignement public, par opposition àanciennement, école primaire publique dirigée par un instituteur, une institutrice laïque ; dans un sens plus général, enseignement public, par opposition àanciennement, école primaire publique dirigée par un instituteur, une institutrice laïque ; dans un sens plus général, enseignement public, par opposition àanciennement, école primaire publique dirigée par un instituteur, une institutrice laïque ; dans un sens plus général, enseignement public, par opposition àanciennement, école primaire publique dirigée par un instituteur, une institutrice laïque ; dans un sens plus général, enseignement public, par opposition àanciennement, école primaire publique dirigée par un instituteur, une institutrice laïque ; dans un sens plus général, enseignement public, par opposition àanciennement, école primaire publique dirigée par un instituteur, une institutrice laïque ; dans un sens plus général, enseignement public, par opposition àanciennement, école primaire publique dirigée par un instituteur, une institutrice laïque ; dans un sens plus général, enseignement public, par opposition à</span><br></p>', '628a124e59a46.jpg', 0);

-- --------------------------------------------------------

--
-- Structure de la table `article_tags`
--

CREATE TABLE `article_tags` (
  `id_article_tags` int(11) NOT NULL,
  `date_article_tags` datetime NOT NULL,
  `article_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `article_tags`
--

INSERT INTO `article_tags` (`id_article_tags`, `date_article_tags`, `article_id`, `tag_id`) VALUES
(1, '2022-05-22 10:17:00', 1, 8),
(2, '2022-05-22 10:17:00', 1, 7),
(3, '2022-05-22 10:18:00', 2, 8),
(4, '2022-05-22 10:29:00', 3, 9),
(5, '2022-05-22 10:29:00', 4, 7),
(6, '2022-05-22 10:32:00', 4, 9),
(7, '2022-05-22 10:32:00', 6, 8),
(8, '2022-05-22 10:37:00', 5, 6),
(9, '2022-05-22 10:37:00', 8, 5);

-- --------------------------------------------------------

--
-- Structure de la table `banniere`
--

CREATE TABLE `banniere` (
  `id_banniere` int(11) NOT NULL,
  `date_banniere` datetime NOT NULL,
  `titre` varchar(100) DEFAULT NULL,
  `sous_titre` varchar(100) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL,
  `statut` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `banniere`
--

INSERT INTO `banniere` (`id_banniere`, `date_banniere`, `titre`, `sous_titre`, `photo`, `statut`) VALUES
(2, '2022-05-22 12:20:00', 'La plateforme des &Eacute;l&egrave;ves et &Eacute;tudiants de Kass&eacute;r&eacute;', 'Une plateforme qui vous donne toutes les informations sur la bagou&eacute;', '628a2aa0d84ab.jpg', 0);

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id_categorie` int(11) NOT NULL,
  `date_categorie` datetime DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id_categorie`, `date_categorie`, `nom`, `slug`) VALUES
(1, '2022-05-02 21:40:00', 'Soci&eacute;t&eacute;', 'societe'),
(2, '2022-05-02 21:40:00', 'Politique', 'politique'),
(3, '2022-05-02 21:40:00', 'Informatique', 'informatique'),
(4, '2022-05-10 08:16:00', 'Sport', 'sport'),
(5, '2022-05-10 08:16:00', 'Sant&eacute;', 'sante'),
(6, '2022-05-10 08:16:00', 'Economie', 'economie'),
(8, '2022-05-22 10:13:00', 'Culture', 'culture');

-- --------------------------------------------------------

--
-- Structure de la table `comment`
--

CREATE TABLE `comment` (
  `id_comment` int(11) NOT NULL,
  `date_comment` datetime NOT NULL,
  `article_id` int(11) DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `statut` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `comment`
--

INSERT INTO `comment` (`id_comment`, `date_comment`, `article_id`, `nom`, `email`, `message`, `statut`) VALUES
(1, '2022-05-22 10:39:00', 5, 'Ouattara Gnelezie Arouna', 'octavie@gmail.com', 'ent, &eacute;cole primaire publique dirig&eacute;e par un instituteur, une institutrice la&iuml;que ; dans un sens plus g&eacute;n&eacute;ral, enseignement public, par oppositient, &eacute;cole primaire publique dirig&eacute;e par un instituteur, une institutrice la&iuml;que ; dans un sens plus g&eacute;n&eacute;ral, enseignement public, par oppositi', 1),
(2, '2022-05-22 10:40:00', 5, 'VEH', 'veh@ci.edu.com', 'ent, &eacute;cole primaire publique dirig&eacute;e par un instituteur, une institutrice la&iuml;que ; dans un sens plus g&eacute;n&eacute;ral, enseignement public, par oppositi gg', 1),
(3, '2022-05-22 10:40:00', 4, 'NAGANA', 'nagana@gmail.com', 'ce pour b&eacute;b&eacute;, c&rsquo;est accepter sa pr&eacute;sence et se pr&eacute;parer &agrave;Faire de la place pour b&eacute;b&eacute;, c&rsquo;est accepter sa pr&eacute;sence et se pr&eacute;parer &agrave;Faire de la place pour b&eacute;b&eacute;, c&rsquo;est accepter sa pr&eacute;sence et se pr&eacute;parer &agrave;Faire de la place', 1),
(4, '2022-05-22 10:41:00', 1, 'Kone Zana', 'wordpress@cinnove.com', '(FEMUA). Parrain de cette &eacute;dition, le chef duLe Premier ministre ivoirien Patrick Achi a communi&eacute; avec les participants Le Premier ministre ivoirien Patrick Achi a', 1),
(5, '2022-05-22 10:41:00', 2, 'Siaka Ouatt', 'siaka@gmail.com', 'cipants Le Premier ministre ivoirien Patrick Achi a communi&eacute; avec les participants &agrave; la 14e &eacute;dition du Festival des musique', 1),
(6, '2022-05-22 10:47:00', 2, 'Siaka', 'siaka@gmail.com', '&eacute;dition du Festival des musiques urbaines d&rsquo;Anoumabo (FEMUA). Parrain de cette &eacute;dition, le chef duLe Premier ministre ivoirien Patrick Achi a communi&eacute; avec les participantsLe Premier ministre ivoirien Patrick Achi a communi&eacute; avec les participants &agrave; la 14e &eacute;dition du Festival des musiques urbaines d&rsquo;Anoumabo (FEMUA). Parrain de cette &eacute;dition, le chef duLe Premier ministre ivoirien Patrick Achi a communi&eacute; avec les participants Le', 1),
(7, '2022-05-22 10:49:00', 2, 'Dok Ciss&eacute;', 'cinnove225@gmail.com', 'a communi&eacute; avec les participants Le Premier ministre ivoirien Patrick Achi a communi&eacute; avec les participants &agrave; la 14e &eacute;dition du Festival des musiques urbaines d&rsquo;Anoumabo (FEMUA). Parrain de cette &eacute;dition, le chef duLe Premie', 1);

-- --------------------------------------------------------

--
-- Structure de la table `events`
--

CREATE TABLE `events` (
  `id_events` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `date_events` date NOT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `slug` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `events`
--

INSERT INTO `events` (`id_events`, `created_date`, `date_events`, `nom`, `slug`) VALUES
(1, '2022-05-22 15:12:00', '2022-05-28', 'Siaka', 'siaka'),
(2, '2022-05-22 15:30:00', '0000-00-00', 'Kone01', 'kone01'),
(3, '2022-05-22 15:31:00', '2022-02-04', 'Kone01', 'kone01-1'),
(4, '2022-05-22 15:42:00', '2022-01-30', 'mangue', 'mangue'),
(5, '2022-05-22 15:48:00', '2022-05-22', 'Siaka Ouatt', 'siaka-ouatt');

-- --------------------------------------------------------

--
-- Structure de la table `gallerie`
--

CREATE TABLE `gallerie` (
  `id_gallerie` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `date_gallerie` datetime DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `gallerie`
--

INSERT INTO `gallerie` (`id_gallerie`, `event_id`, `date_gallerie`, `photo`) VALUES
(1, 5, '2022-05-22 21:35:00', '628aac993f449.png'),
(2, 5, '2022-05-22 21:36:00', '628aacc32b5f7.png'),
(3, 5, '2022-05-22 21:38:00', '628aad5bb0329.png'),
(4, 5, '2022-05-22 21:39:00', '628aad74d9af3.jpg'),
(5, 5, '2022-05-22 21:54:00', '628ab12050aa6.png'),
(6, 3, '2022-05-22 22:02:00', '628ab30ca8884.png');

-- --------------------------------------------------------

--
-- Structure de la table `reponse`
--

CREATE TABLE `reponse` (
  `id_reponse` int(11) NOT NULL,
  `date_reponse` datetime DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  `comment_id` int(11) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `statut` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `reponse`
--

INSERT INTO `reponse` (`id_reponse`, `date_reponse`, `article_id`, `comment_id`, `email`, `nom`, `message`, `statut`) VALUES
(1, '2022-05-22 11:23:00', 2, 6, 'membre@gmail.com', 'Zie', 'Merci pour commentaire', 0),
(2, '2022-05-22 11:23:00', 2, 7, 'membre@gmail.com', 'Zie', 'ok', 0),
(3, '2022-05-22 11:23:00', 1, 4, 'membre@gmail.com', 'Zie', 'ok', 0),
(4, '2022-05-22 11:30:00', 2, 5, 'membre@gmail.com', 'Zie', 'C\\\'est fait', 0),
(5, '2022-05-22 11:32:00', 4, 3, 'membre@gmail.com', 'Zie', 'gggghhh', 0),
(6, '2022-05-22 11:37:00', 1, 4, 'Prnom@kk.mm', 'Repos 5', '025', 0),
(7, '2022-05-22 11:38:00', 4, 3, 'wordpress@cinnove.com', 'Repos', '58', 0);

-- --------------------------------------------------------

--
-- Structure de la table `stats_visite`
--

CREATE TABLE `stats_visite` (
  `ip` varchar(30) NOT NULL,
  `date_visite` date NOT NULL,
  `navigateur` varchar(55) DEFAULT NULL,
  `devices` varchar(55) DEFAULT NULL,
  `pages_vues` smallint(5) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `stats_visite`
--

INSERT INTO `stats_visite` (`ip`, `date_visite`, `navigateur`, `devices`, `pages_vues`) VALUES
('::1', '2022-05-21', 'Chrome', 'pc', 17),
('127.0.0.1', '2022-05-21', 'Firefox', 'pc', 2),
('::1', '2022-05-22', 'Chrome', 'pc', 59);

-- --------------------------------------------------------

--
-- Structure de la table `tag`
--

CREATE TABLE `tag` (
  `id_tag` int(11) NOT NULL,
  `date_tag` datetime NOT NULL,
  `nom` varchar(55) DEFAULT NULL,
  `slug` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tag`
--

INSERT INTO `tag` (`id_tag`, `date_tag`, `nom`, `slug`) VALUES
(1, '2022-05-22 06:48:00', 'Politique', 'politique'),
(2, '2022-05-22 06:48:00', 'Association', 'association'),
(3, '2022-05-22 06:48:00', 'Paix', 'paix'),
(4, '2022-05-22 06:48:00', 'Soci&eacute;t&eacute;', 'societe'),
(5, '2022-05-22 06:49:00', 'Ecole', 'ecole'),
(6, '2022-05-22 06:49:00', '&eacute;ducation', 'education'),
(7, '2022-05-22 06:49:00', 'Solidarit&eacute;', 'solidarite'),
(8, '2022-05-22 06:50:00', 'Finance', 'finance'),
(9, '2022-05-22 06:50:00', 'Argent', 'argent'),
(10, '2022-05-22 06:51:00', 'D&eacute;veloppement', 'developpement');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_2` (`email`);

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id_article`);

--
-- Index pour la table `article_tags`
--
ALTER TABLE `article_tags`
  ADD PRIMARY KEY (`id_article_tags`),
  ADD KEY `article_id` (`article_id`),
  ADD KEY `tag_id` (`tag_id`);

--
-- Index pour la table `banniere`
--
ALTER TABLE `banniere`
  ADD PRIMARY KEY (`id_banniere`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id_categorie`);

--
-- Index pour la table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id_comment`),
  ADD KEY `article_id` (`article_id`);

--
-- Index pour la table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id_events`);

--
-- Index pour la table `gallerie`
--
ALTER TABLE `gallerie`
  ADD PRIMARY KEY (`id_gallerie`);

--
-- Index pour la table `reponse`
--
ALTER TABLE `reponse`
  ADD PRIMARY KEY (`id_reponse`),
  ADD KEY `comment_id` (`comment_id`);

--
-- Index pour la table `stats_visite`
--
ALTER TABLE `stats_visite`
  ADD PRIMARY KEY (`ip`,`date_visite`),
  ADD KEY `date_visite` (`date_visite`);

--
-- Index pour la table `tag`
--
ALTER TABLE `tag`
  ADD PRIMARY KEY (`id_tag`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `article`
--
ALTER TABLE `article`
  MODIFY `id_article` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `article_tags`
--
ALTER TABLE `article_tags`
  MODIFY `id_article_tags` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `banniere`
--
ALTER TABLE `banniere`
  MODIFY `id_banniere` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id_categorie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `comment`
--
ALTER TABLE `comment`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `events`
--
ALTER TABLE `events`
  MODIFY `id_events` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `gallerie`
--
ALTER TABLE `gallerie`
  MODIFY `id_gallerie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `reponse`
--
ALTER TABLE `reponse`
  MODIFY `id_reponse` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `tag`
--
ALTER TABLE `tag`
  MODIFY `id_tag` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
